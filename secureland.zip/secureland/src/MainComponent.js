import React from 'react'
import logo from "./Ap/images/mainPage_logo.jpg"
import './MainComponent.css'
import { Link } from 'react-router-dom'
import slideShow1 from './Ap/images/background_img.jpg'
import slideShow2 from './Ap/images/slideShowimg.jpg'
import slideShow3 from './Ap/images/slideShowimg2.jpg'
import Footer from './Ap/footer/Footer'
const MainComponent = () => {

  return (
    <div>
        <div className='container'>
            {/* Navbar */}
            <div className='row'>
                <div className='col'>
                <img src={logo} alt="logo" width="100" height="100" style={{borderRadius:"50%"}}/>
                <h2 style={{fontSize:"45px"}}>Secure Land Management</h2>
                </div>
                <div className='col-4 mt-5'>
                    <h3>State: </h3>
                    <button className='btn btn-success m-3'><Link to="/mainPage" style={{textDecoration:"none",color:"white"}}>Andhra Pradesh</Link></button>
                    <button className='btn btn-success'><Link to="*" style={{textDecoration:"none",color:"white"}}>Telangana</Link></button>
                </div>
            </div>
  
            <div id="carouselExampleControlsNoTouching" class="carousel slide" data-bs-touch="false">
              <div class="carousel-inner">
                <div class="carousel-item active">
                  <img src={slideShow1} className="d-block w-100 slide" alt="..." />
                </div>
                <div class="carousel-item">
                  <img src={slideShow2} class="d-block w-100 slide" alt="..." />
                </div>
                <div class="carousel-item">
                  <img src={slideShow3} class="d-block w-100 slide" alt="..." />
                </div>
              </div>
              <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControlsNoTouching" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
              </button>
              <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControlsNoTouching" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
              </button>
            </div>


            <Footer />
        </div>
    </div>
  )
}

export default MainComponent